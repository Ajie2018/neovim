#include <iostream>

void foo(int x) {
    std::cout << x
        << x + 1
        << x + 2;
}
