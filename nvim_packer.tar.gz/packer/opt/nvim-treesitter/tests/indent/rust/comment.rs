/// Function foo
///
/// Description of
/// function foo.
fn foo(x: i32, y: i32) -> i32 {
    x + y
}
