if a == a:
    x = 1
elif b:
    x = 2
else:
    x = 3

while False:
    pass

for _ in range(3):
    pass

with open('/tmp/f', 'w') as f:
    pass

try:
    pass
except:
    pass
finally:
    pass
