# cmp-path

nvim-cmp source for filesystem paths.

# Setup

```lua
require'cmp'.setup {
  sources = {
    { name = 'path' }
  }
}
```


